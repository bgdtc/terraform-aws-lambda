module.exports = {handler: async function (event) { return {statusCode: 200, body: "{}", headers: {'Content-Type': 'application/json;charset=utf-8'}}; }}
